# SpoonacularApi.InlineObject4

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instructions** | **String** | The instructions to be analyzed. | 


